let count = 0; // This will count how many ships we make

function setup() {
  
  // Create our canvas
  createCanvas(600, 600);
  
  // Set our background color
  background(0);
  
  // Set our color mode
  colorMode(RGB, 255, 255, 255, 1);
  
  // Set our angle mode
  angleMode(DEGREES);
 
}

function draw() {
	
	// Reset count variable
	count = 0;

    // Draw our first set of ships
	for(var x = 5; x < width - 5; x += 35){
		for(var y  = 5; y <= 120; y += 35){
			drawShip(x, y, "GREEN");
		}
	}
	
	// Check how many ships were made
	print(shipCount());
	
	// Move to where we will draw the second set of ships
	translate(150, 400);
	
	// Rotate the coordinates
	rotate(180);
	
	// Scale the coordinate system
	scale(4);
	
	// Draw our second set of ships
	for(var i = 0; i < width/4; i += 50){
		drawShip((0-i), 0, "BLUE");
	}
	
	// Check again how many ships were made
	print(shipCount());
	
}

// Draws a ship at (xPos, yPos) using the passed color
function drawShip(xPos, yPos, color){
	
	push();
	
	// Draw the squares that will make our ship
	fill(color);
	stroke(0);
	strokeWeight(1);
	translate(xPos, yPos);
	square(0, 0, 10);
	square(20, 0, 10);
	square(0, 10, 10);
	square(10, 10, 10);
	square(20, 10, 10);
	square(10, 20, 10);
	
	pop();
	
	count++;
}

// Returns the number of ships that have been created so far
function shipCount(){
	return count;
}